<?php
ob_start();

require_once("../../InstallConfig/configure.php");
require_once("clearcmslib/Mappers/FileFinder.php");
require_once("clearcmslib/Mappers/FileGateway.php");

require_once("clearcmslib/Session/Session.php");
require_once("clearcmslib/AccessControl/FrontEndAuth.php");

require_once("clearcmslib/RequestRegistry.php");


//new request registry object
$requestObj = new RequestRegistry();

// Instantiate the Auth class
$auth = &new FrontEndAuth($requestObj, '/downloads/login.php', ACCESS_PASSWORD_SALT);



// For logging out
/*if ($requestObj->getParam('action')  == 'logout') {
 $auth->logout();
} */


if($id=$requestObj->getParam('id')){

	$fileObj= FileFinder::fetch($id);
	if($fileObj!=false){

		if(PermissionsManager::canDo(PERMISSION_GENERIC_CAN_VIEW,$id,Session::get('userId'),OBJECT_TYPE_ID_FILE)){


			$fileroot=$_SERVER['DOCUMENT_ROOT'].CMS_MEDIA_LIB."/File/";

				$filetemp=escapeshellarg($fileroot.$id);


			$mimeType =`file -bi {$filetemp}`;
			$mimeType = rtrim($mimeType);
			//need to do this incase there is  any trailing info after the mimetype itself eg ;charset=
			//we need the clean mimetype of type foo/bar to use as the index to get the correct file extension
			$mimeArray = explode(";",$mimeType);

			if($fileObj->isWebImage()===false){
				UserError::displayMessage("Invalid file type. Only images can be displayed using this system.");
			}

			if(is_file($fileroot.$id)){
				if(ini_get('zlib.output_compression')){
					ini_set('zlib.output_compression', 'Off');
				}

					$fp = fopen($fileroot.$id, "rb");

			} else{
				$fp = fopen($_SERVER['DOCUMENT_ROOT']."/images/icons/128x128/mimetypes/image128x128.gif", "rb");
			}

			header("Pragma: public");
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
			header("Cache-Control: private",false);
			header("Content-Transfer-Encoding: binary");
			header("Content-Type: " . $mimeType);
			fpassthru($fp);

		} else{
			UserError::displayMessage("Access Denied");
		}
	} else {
		UserError::displayMessage('Invalid file. Please try again');
	}
}

ob_flush();
ob_clean();
?>