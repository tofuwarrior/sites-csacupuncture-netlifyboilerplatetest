<?php
ob_start();
require_once ('../../InstallConfig/configure.php');


require_once("clearcmslib/Mappers/FileFinder.php");
require_once("clearcmslib/Mappers/FileGateway.php");

require_once("clearcmslib/Session/Session.php");

require_once("clearcmslib/AccessControl/FrontEndAuth.php");

require_once("clearcmslib/AccessControl/PermissionsManager.php");


require_once("clearcmslib/RequestRegistry.php");


//new request registry object
$requestObj = new RequestRegistry();



// Instantiate the Auth class
//$auth = &new FrontEndAuth($requestObj, $_SERVER['REQUEST_URI'], ACCESS_PASSWORD_SALT);


if($id=$requestObj->getParam('id')){

	$fileObj= FileFinder::fetch($id);

	if($fileObj!=false){

		if(PermissionsManager::canDo(PERMISSION_GENERIC_CAN_VIEW,$id,Session::get('userId'),OBJECT_TYPE_ID_FILE)){

			switch($requestObj->getParam('type','IS_STRING')){
				case 'preview':
					$string='tmp';
				break;

				case 'thumb':
					$string='thumbs';
				break;

				default:
					$string='';
			}


			$fileroot=$_SERVER['DOCUMENT_ROOT'].CMS_MEDIA_LIB."/File/".$string."/";

			$filetemp=escapeshellarg($fileroot.$string.$id);
			$mimeType =`file -bi {$filetemp}`;
			$mimeType = rtrim($mimeType);
			//need to do this incase there is  any trailing info after the mimetype itself eg ;charset=
			//we need the clean mimetype of type foo/bar to use as the index to get the correct file extension
			$mimeArray = explode(";",$mimeType);

			$result = is_dir("/home/httpd/vhosts/environment-wales.org/clearcmsmedia/File/");

			if(is_file($fileroot.$string.$id)){



				if(ini_get('zlib.output_compression')){
					ini_set('zlib.output_compression', 'Off');
				}

					header("Pragma: public");
					header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
					header("Cache-Control: private",false);
					header("Content-Transfer-Encoding: binary");
					header("Content-Type: " . $mimeType);

					if($fileObj->isWebImage()==false){
						$fileObj->setName(rtrim($fileObj->getName()));
						$pos=strrchr($fileObj->getName(),'.');
						if($pos===false||$pos>5){
							$fileObj->setName( $fileObj->getName().$permittedMimeTypes[$mimeType]['extension']);
						}
						header('Content-Disposition: attachment; filename="'.$fileObj->getName().'"');

					}

					//address ie bug with text mime types and attachment saving in https etc
					if(isset($mimeType) && strstr($mimeType, "text/"))
					{
						$fp = fopen($fileroot.$string.$id, "r");
					}
					else
					{
						$fp = fopen($fileroot.$string.$id, "rb");
					}
					//header('Content-length: '.filesize($fp));

					fpassthru($fp);

			} else{

				UserError::displayMessage("Invalid file.");
			}
		} else{
			UserError::displayMessage("Access Denied");
		}
	} else {
		UserError::displayMessage('Invalid file.Please try again');
		exit();
	}
}


ob_flush();
ob_clean();

?>