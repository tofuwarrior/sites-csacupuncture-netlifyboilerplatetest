<?php
ob_start();

require_once("../../InstallConfig/configure.php");
require_once("clearcmslib/Mappers/FileFinder.php");
require_once("clearcmslib/Mappers/FileGateway.php");

require_once("clearcmslib/Session/Session.php");
require_once("clearcmslib/AccessControl/FrontEndAuth.php");

require_once("clearcmslib/RequestRegistry.php");
require_once("clearcmslib/Mappers/ThumbnailFinder.php");


//new request registry object
$requestObj = new RequestRegistry();

// Instantiate the Auth class
$auth = &new FrontEndAuth($requestObj, '/downloads/login.php', ACCESS_PASSWORD_SALT);

// For logging out
/*if ($requestObj->getParam('action')  == 'logout') {
 $auth->logout();
} */



	$module =$requestObj->getParam('module','IS_STRING');
	if($module!==false){
		//if the configuration file exists load it and set the thumbheight to be the default
		if(is_file('clearcmslib/Conf/Module'.$module.'Conf.php')){
			require_once('clearcmslib/Conf/Module'.$module.'Conf.php');
		}
		$module= strtoupper($module);
		//set the thumbheight
		if(@constant('CMS_MODULE_'.$module.'_THUMBHEIGHT')){
			$thumbHeight= constant('CMS_MODULE_'.$module.'_THUMBHEIGHT');
		} else{
			$thumbHeight= CMS_DEFAULT_THUMB_HEIGHT;
		}



	} else{

		$thumbHeight= CMS_DEFAULT_THUMB_HEIGHT;
	}



	$thumbnailObj = ThumbnailFinder::fetch($requestObj->getParam('id'));
	if($thumbnailObj!=false){

		$fileroot=$_SERVER['DOCUMENT_ROOT'].CMS_MEDIA_LIB."/File/";
		$fileroot=$fileroot.'thumbs/';

		$filetemp=escapeshellarg($fileroot.$thumbnailObj->getFileName());
		$file=$fileroot.$thumbnailObj->getFileName();

	} else{
		$file=false;
	}

	$type=$requestObj->getParam('type','IS_STRING');
	if($type==false){
		$type='image';
	}
	//if the file doesn't exist then default ot the default thumbnail file for this request
	if(!is_file($file)||$file===false){
		//define the file as the custom default thumbnail file
		$file=$_SERVER['DOCUMENT_ROOT']."/images/icons/".$thumbHeight."x64/mimetypes/".$type.".png";
		$filetemp=escapeshellarg($file);
		//check if the custom thumbnail file exists. If not default to the default
		if(!is_file($file)){
			$file=$_SERVER['DOCUMENT_ROOT']."/images/icons/64x64/mimetypes/image.png";
			$filetemp=escapeshellarg($file);
		}
	}




	$mimeType =`file -bi {$filetemp}`;
	$mimeType = rtrim($mimeType);
	//need to do this incase there is  any trailing info after the mimetype itself eg ;charset=
	//we need the clean mimetype of type foo/bar to use as the index to get the correct file extension
	$mimeArray = explode(";",$mimeType);

		if(ini_get('zlib.output_compression')){
			ini_set('zlib.output_compression', 'Off');
		}

		header("Pragma: public");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Cache-Control: private",false);
		header("Content-Transfer-Encoding: binary");
		header("Content-Type: " . $mimeType);
		$fp = fopen($file, "rb");
		fpassthru($fp);




ob_flush();
ob_clean();
?>